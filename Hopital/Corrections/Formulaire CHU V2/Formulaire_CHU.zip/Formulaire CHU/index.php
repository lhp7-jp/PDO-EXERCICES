<?php

header('Location: views/home.php');

// ceci est une bonne pratique
exit();