<?php

define('DBNAME', 'hospitale2n');
define('DBUSER', 'hopital');
define('DBPASSWORD', 'hopital');