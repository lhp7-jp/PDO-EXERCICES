<?php

require_once '../config.php';
require_once '../models/DataBase.php';
require_once '../models/patient.php';