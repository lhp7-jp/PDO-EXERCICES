<?php

define('DBNAME', 'colyseum');
define('DBUSER', 'colyseum');
define('DBPASSWORD', 'colyseum');